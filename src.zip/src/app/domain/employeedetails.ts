import { Login } from "./login";
import { ProjectDetails } from "./projectdetails";

export class EmployeeDetails
{
    employeeId : number = 0;
    firstName : string = "";
    lastName : string = "";
    contact : number = 0;
    designation : string = "";
    skill1 : string = "";
    skill2 : string = "";
    skill3 : string = "";
    bench  :string= "";
    salary : number = 0;
    address : string = "";
    city :string = "";
    state : string ="";
    pincode : number = 0;
    login : Login = new Login();
    projectDetails : ProjectDetails = new ProjectDetails();
    mgr : number = 0;
    
}