import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HrMenuPageComponent } from './hr-menu-page.component';

describe('HrMenuPageComponent', () => {
  let component: HrMenuPageComponent;
  let fixture: ComponentFixture<HrMenuPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HrMenuPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HrMenuPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
