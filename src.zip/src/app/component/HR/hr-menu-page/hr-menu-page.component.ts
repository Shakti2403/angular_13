import { Component, OnInit } from '@angular/core';
import { JobRequest } from 'src/app/domain/jobrequest';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-hr-menu-page',
  templateUrl: './hr-menu-page.component.html',
  styleUrls: ['./hr-menu-page.component.css']
})
export class HrMenuPageComponent implements OnInit {

  
  constructor() { }
  
  ngOnInit(): void {
  }

  
 
}
