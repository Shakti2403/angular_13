import { Component, OnInit } from '@angular/core';
import { ApplicantDetails } from 'src/app/domain/applicant';
import { ApplicantCrudService } from 'src/app/service/applicant-crud.service';

@Component({
  selector: 'app-applicant-details',
  templateUrl: './applicant-details.component.html',
  styleUrls: ['./applicant-details.component.css']
})
export class ApplicantDetailsComponent implements OnInit {
  result : boolean = false;
  applicantDetails : ApplicantDetails = new ApplicantDetails();
  constructor(private applicantCrudService : ApplicantCrudService) { }

  ngOnInit(): void {
  }

 




}
