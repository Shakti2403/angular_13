import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PmJobRequestComponent } from './pm-job-request.component';

describe('PmJobRequestComponent', () => {
  let component: PmJobRequestComponent;
  let fixture: ComponentFixture<PmJobRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PmJobRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PmJobRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
