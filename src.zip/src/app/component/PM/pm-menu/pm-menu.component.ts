import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pm-menu',
  templateUrl: './pm-menu.component.html',
  styleUrls: ['./pm-menu.component.css']
})
export class PmMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
