import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditJobRequestComponent } from './edit-job-request.component';

describe('EditJobRequestComponent', () => {
  let component: EditJobRequestComponent;
  let fixture: ComponentFixture<EditJobRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditJobRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditJobRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
