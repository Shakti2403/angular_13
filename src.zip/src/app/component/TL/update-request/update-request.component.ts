import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-update-request',
  templateUrl: './update-request.component.html',
  styleUrls: ['./update-request.component.css']
})
export class UpdateRequestComponent implements OnInit {

  submitted:boolean = false;
  result: boolean = false;
  jobId: number = 0;

  constructor(private router : Router,
    private activateroute: ActivatedRoute,
    private jobrequestcrud: JobRequestCrudService) { }

  ngOnInit(): void {
    console.log("in UpdateDetailsComponent");
    this.jobId = this.activateroute.snapshot.params['jobId'];

    
  }

  updateDetails(){
  
  }

  backToExistingRequest()
  {
    this.router.navigate(["existingrequest", this.jobId]);
  }
}
