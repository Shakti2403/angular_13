import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JobRequest } from 'src/app/domain/jobrequest';
import { JobRequestCrudService } from 'src/app/service/job-request-crud.service';

@Component({
  selector: 'app-career-page',
  templateUrl: './career-page.component.html',
  styleUrls: ['./career-page.component.css']
})
export class CareerPageComponent implements OnInit {

  constructor(private router: Router, private jobServiceCrud : JobRequestCrudService) { }
 
  jobReq : JobRequest[] = [];
  ngOnInit(): void 
  {
    this.getJobReqByStatusOnCareerPage();
  }

  ToApplicantPage(){
    this.router.navigate(['toApplicantPage']);
  }


  getJobReqByStatusOnCareerPage()
  { console.log("getJobReqByStatusOnCareerPage");
     this.jobServiceCrud.getJobReqByStatusOnCareerPage().subscribe(
      data =>{
         this.jobReq = data;
         console.log(this.jobReq);
         
      }
     );
  }

 

}
