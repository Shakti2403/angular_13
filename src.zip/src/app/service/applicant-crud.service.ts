import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApplicantDetails } from '../domain/applicant';


@Injectable({
  providedIn: 'root'
})
export class ApplicantCrudService {

  baseURL: string = "http://localhost:8080/applicantdetailsapi";
  constructor(private httpClient: HttpClient) { }
  
addNewApplicantDetails(applicantdetails : ApplicantDetails) : Observable<boolean>
{
   return this.httpClient.post<boolean>(this.baseURL+"/insertnewapplicant" , applicantdetails);
}
}
