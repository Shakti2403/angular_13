import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../domain/employeedetails';
import { JobRequest } from '../domain/jobrequest';

@Injectable({
  providedIn: 'root'
})
export class JobRequestCrudService {

  baseURL: string = "http://localhost:8080/jobrequestapi";
  constructor(private httpClient: HttpClient) { }

  AddNewRequest(jobrequest: JobRequest): Observable<boolean> {
    console.log("In Add New request");
    console.log(jobrequest);
    return this.httpClient.post<boolean>(this.baseURL + "/jobrequest", jobrequest);
  }

  getAllPendingJobRequests(userId: number): Observable<JobRequest[]> {
    console.log(userId);
    return this.httpClient.get<JobRequest[]>(this.baseURL + "/jobrequestbyuserid/" + userId)
  }

  updateJobRequest(jobrequest: JobRequest): Observable<boolean> {
    return this.httpClient.put<boolean>(this.baseURL + "/jobrequest/update", jobrequest);
  }

  getDetailsByLoginId(userId: number): Observable<JobRequest[]> {
    console.log(userId);

    return this.httpClient.get<JobRequest[]>(this.baseURL + "/jobrequestbymanageruserid/" + userId);
  }

  getJobByJobId(jobId: number): Observable<JobRequest> {
    console.log("in getJobByJobId");

    console.log(jobId);
    return this.httpClient.get<JobRequest>(this.baseURL + "/jobbyjobid/" + jobId);

  }

  UpdateJobRequestCount(jobrequest: JobRequest): Observable<JobRequest> {
    return this.httpClient.put<JobRequest>(this.baseURL + "/updatejobrequestbycount", jobrequest);
  }

  UpdateRequestStatus(jobrequest: JobRequest): Observable<JobRequest> {
    return this.httpClient.put<JobRequest>(this.baseURL + "/updatejobrequestbystatus", jobrequest);
  }


  SendToHR() : Observable<JobRequest[]>
  {
    console.log("In SentToHr()");
    return this.httpClient.get<JobRequest[]>(this.baseURL + "/jobrequestbystatus/all");
  }

  SendJobToCareerPage(jobRequest :JobRequest) : Observable<boolean>{
    console.log("in SendJobToCareerPage()"); 
    return this.httpClient.put<boolean>(this.baseURL+"/updatejobrequestbystatusoncareerpage",jobRequest);

  }

  getJobReqByStatusOnCareerPage() : Observable<JobRequest[]>{
    console.log("in getJobReqByStatusOnCareerPage");
    return this.httpClient.get<JobRequest[]>(this.baseURL+"/jobrequestbystatusoncareerpage/all");
 
  }

  

  











}
